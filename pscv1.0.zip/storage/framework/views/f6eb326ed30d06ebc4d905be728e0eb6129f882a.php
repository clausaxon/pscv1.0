 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header'); ?> 
        <p class="text-3xl text-center">Menu</p>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <a href="<?php echo e(url('suratkeluar')); ?>">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold text-xl w-full py-10 px-20 rounded">
                    Surat Keluar PSC
                </button>
                </a>
                </br>
                </br>
                <a href="<?php echo e(url('suratstk')); ?>">
                <button class="bg-green-500 hover:bg-green-700 text-white font-bold text-xl w-full py-10 px-20 rounded">
                    Registrasi STK
                </button>
                </a>
                </br>
                </br>
                <button class="bg-red-500 hover:bg-red-700 text-white font-bold text-xl w-full py-10 px-20 rounded">
                    Pembuatan PS
                </button>
                </br>
                </br>
                <a href="<?php echo e(url('lib')); ?>">
                <button class="bg-transparent hover:bg-black text-black-700 font-semibold text-xl hover:text-white w-full py-10 px-20 border border-black hover:border-transparent rounded">
                    Library
                </button>
                </br>
                </br>
                <a href="<?php echo e(url('log')); ?>">
                <button class="bg-transparent hover:bg-black text-black-700 font-semibold text-xl hover:text-white w-full py-10 px-20 border border-black hover:border-transparent rounded">
                    Status Log
                </button>
                </a>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH D:\pscv1.0\resources\views/dashboard.blade.php ENDPATH**/ ?>